import logo from './logo.svg';
import './App.css';
import Tabla from './Tabla'
import {useState} from 'react';

function App() {

  const[counter, setCounter]= useState(0);
  const[nombre, setNombre]= useState();
  const[ApellidoP, setApellidoP]=useState();
  const[ApellidoM, setApellidoM]=useState();
  const[sexo, setSexo]=useState();
  const[Telefono, setTelefono]=useState();
  const[Direccion, setDireccion]=useState();
  const[CP, setCP]=useState();
  const[edad, setedad]=useState();
  const[Nacionalidad, setnac]=useState();
  const[email, setemail]=useState();



  function onAdd(){
    let resultado = counter +1;
    setCounter(resultado);

  }

  function onReduce(){
    let resultado = counter -1;
    setCounter(resultado);
  }

  function onName(){
  }
  
  return (
    <div className="App">
     <p>contador</p>
     <p>{counter}</p>
     <p>{nombre}</p>
     <input onChange={(e)=>setNombre(e.target.value)}type='text' placeholder='Nombre'></input>
     <br></br>
     <input onChange={(e)=>setApellidoP(e.target.value)}type='text' placeholder='Apellido Paterno'></input>
     <br></br>
     <input onChange={(e)=>setApellidoM(e.target.value)}type='text' placeholder='Apellido Materno'></input>
     <br></br>
     <input onChange={(e)=>setSexo(e.target.value)}type='text' placeholder='Sexo'></input>
     <br></br>
     <input onChange={(e)=>setTelefono(e.target.value)}type='phone' placeholder='Telefono'></input>
     <br></br>
     <input onChange={(e)=>setDireccion(e.target.value)}type='text' placeholder='Dirección'></input>
     <br></br>
     <input onChange={(e)=>setCP(e.target.value)}type='text' placeholder='Codigo postal'></input>
     <br></br>
     <input onChange={(e)=>setedad(e.target.value)}type='text' placeholder='Edas'></input>
     <br></br>
     <input onChange={(e)=>setnac(e.target.value)}type='text' placeholder='Nacionalidad'></input>
     <br></br>
     <input onChange={(e)=>setemail(e.target.value)}type='e-mail' placeholder='Correo electronico'></input>
     <br></br>
     <br></br>
     <button onClick={()=>setCounter(counter+1)}>Guardar</button>
     <button onClick={()=>setCounter(counter-1)}>Cancelar</button>



    </div>
  );
}

export default App;
